# Long Doge Challenge
A "Useless Website" honoring our lord and savior Doge, encouraging the printing of an endlessly scrolled doge

![Long Doge Challenge](https://longdogechallenge.com/assets/share.png)

- Originally live coded on [twitch](https://www.twitch.tv/timbuildsuselesswebsites)... watchable here https://www.youtube.com/watch?v=Iksq8oaebMw
- Hosted @ https://longdogechallenge.com/

The long doge challenge is a srolling adventure challenge of the most difficult kind... the ultimate goal is to achieve the rare hatted doge, which you should then most certainly print.

Like useless sites? Support me on GitHub https://github.com/sponsors/tholman/ for more
